# Clock-In System

## Overview
The Clock-In System is a web-based application designed to manage employee clock-in and clock-out activities. It provides a user-friendly interface for selecting employees, dates, locations, and uploading images. The system tracks the time each employee clocks in and out, ensuring accurate attendance records.

## Project Structure
```
clock-in-system
├── css
│   └── styles.css        # Styles for the clock-in system
├── js
│   └── script.js         # JavaScript functionality for the clock-in system
├── index.html            # Main HTML document for the clock-in system
└── README.md             # Documentation for the project
```

## Setup Instructions
1. **Clone the Repository**
   Clone this repository to your local machine using:
   ```
   git clone <repository-url>
   ```

2. **Navigate to the Project Directory**
   ```
   cd clock-in-system
   ```

3. **Open the `index.html` File**
   Open `index.html` in your web browser to view the application.

## Usage Guidelines
- Select an employee from the dropdown menu.
- Choose the date for the clock-in/out action.
- Select the location from the provided options.
- Optionally, upload a photo of the guard.
- Click the "Clock In" button to record the start of the shift.
- Click the "Clock Out" button to record the end of the shift.

## Contributing
Contributions are welcome! Please feel free to submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License.