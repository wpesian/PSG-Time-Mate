// Function to update the clock
function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    document.getElementById('time').textContent = `${hours}:${minutes}:${seconds}`;
}

// Update the clock every second
setInterval(updateClock, 1000);
updateClock(); // Initial call

// Function to handle Clock In
async function handleClockIn() {
    const employeeId = document.getElementById('employee-dropdown').value;
    const employeeName = document.getElementById('employee-dropdown').options[document.getElementById('employee-dropdown').selectedIndex].text;
    const date = document.getElementById('date').value;
    const location = document.getElementById('location').value;
    const imageFile = document.getElementById('image-upload').files[0];

    const formData = new FormData();
    formData.append('employeeId', employeeId);
    formData.append('employeeName', employeeName);
    formData.append('date', date);
    formData.append('location', location);
    formData.append('action', 'Clock In');
    if (imageFile) {
        formData.append('image', imageFile);
    }

    try {
        const response = await fetch('https://script.google.com/macros/s/your-script-id/exec', {
            method: 'POST',
            body: formData,
        });

        if (response.ok) {
            alert(`${employeeName} (${employeeId}) has clocked in at ${location} on ${date}.`);
        } else {
            alert("Failed to record the action. Please try again.");
        }
    } catch (error) {
        console.error("Error:", error);
        alert("An error occurred. Please check your connection.");
    }
}

// Function to handle Clock Out
async function handleClockOut() {
    const employeeId = document.getElementById('employee-dropdown').value;
    const employeeName = document.getElementById('employee-dropdown').options[document.getElementById('employee-dropdown').selectedIndex].text;
    const date = document.getElementById('date').value;
    const location = document.getElementById('location').value;
    const imageFile = document.getElementById('image-upload').files[0];

    const formData = new FormData();
    formData.append('employeeId', employeeId);
    formData.append('employeeName', employeeName);
    formData.append('date', date);
    formData.append('location', location);
    formData.append('action', 'Clock Out');
    if (imageFile) {
        formData.append('image', imageFile);
    }

    try {
        const response = await fetch('https://script.google.com/macros/s/AKfycbz9xcSzinM6tFnNMw1uVQuvmyDGgZXLHWOW2SEgj43Vc9KmgrpbkBDAMqpFYe0bZRyz/exec', {
            method: 'POST',
            body: formData,
        });

        if (response.ok) {
            alert(`${employeeName} (${employeeId}) has clocked out at ${location} on ${date}.`);
        } else {
            alert("Failed to record the action. Please try again.");
        }
    } catch (error) {
        console.error("Error:", error);
        alert("An error occurred. Please check your connection.");
    }
}